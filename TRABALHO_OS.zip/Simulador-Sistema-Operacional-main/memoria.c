#include <stdio.h>
#include "memoria.h"
#include "processos.h"
#include "utils.h"

#define MAX_BLOCOS 100

BlocoMemoria blocos_memoria[MAX_BLOCOS];
int num_blocos = 0;

/**
 * Inicializa a mem�ria com um �nico bloco livre de 1024 MB.
 */
void inicializarMemoria() {
    num_blocos = 1;
    blocos_memoria[0].base = 0;
    blocos_memoria[0].tamanho = MEMORIA_TOTAL;
    blocos_memoria[0].pid = 0;
}

/**
 * Mescla blocos livres adjacentes para evitar fragmenta��o.
 */
static void mesclarBlocos() {
    int i = 0;
    while (i < num_blocos - 1) {
        if (blocos_memoria[i].pid == 0 && blocos_memoria[i + 1].pid == 0) {
            // Mescla
            blocos_memoria[i].tamanho += blocos_memoria[i + 1].tamanho;
            // Desloca os blocos seguintes
            for (int j = i + 1; j < num_blocos - 1; j++) {
                blocos_memoria[j] = blocos_memoria[j + 1];
            }
            num_blocos--;
        } else {
            i++;
        }
    }
}

/**
 * Aloca mem�ria para um processo usando First Fit.
 * Retorna 1 se bem-sucedido, 0 caso contr�rio.
 */
void alocarMemoria(int pid, int tamanho) {
    if (tamanho <= 0) {
        printf("Tamanho inv�lido.\n");
        return;
    }

    // Verificar se o processo j� tem mem�ria alocada
    for (int i = 0; i < num_blocos; i++) {
        if (blocos_memoria[i].pid == pid) {
            printf("Processo %d ja possui memoria alocada.\n", pid);
            return;
        }
    }

    // Buscar primeiro bloco livre com tamanho suficiente
    int i;
    for (i = 0; i < num_blocos; i++) {
        if (blocos_memoria[i].pid == 0 && blocos_memoria[i].tamanho >= tamanho) {
            break;
        }
    }
    if (i == num_blocos) {
        printf("Memoria insuficiente para alocar %d MB.\n", tamanho);
        return;
    }

    // Alocar
    BlocoMemoria *bloco = &blocos_memoria[i];
    if (bloco->tamanho == tamanho) {
        bloco->pid = pid;
    } else {
        // Divide o bloco
        // Inserir novo bloco ap�s o atual
        if (num_blocos >= MAX_BLOCOS) {
            printf("Erro: numero maximo de blocos atingido.\n");
            return;
        }
        // Desloca para abrir espa�o
        for (int j = num_blocos; j > i + 1; j--) {
            blocos_memoria[j] = blocos_memoria[j - 1];
        }
        // O novo bloco � o restante
        BlocoMemoria novo;
        novo.base = bloco->base + tamanho;
        novo.tamanho = bloco->tamanho - tamanho;
        novo.pid = 0;
        blocos_memoria[i + 1] = novo;
        // Atualiza o bloco atual
        bloco->tamanho = tamanho;
        bloco->pid = pid;
        num_blocos++;
    }
    printf("Alocado %d MB para o processo %d.\n", tamanho, pid);
}

/**
 * Libera a mem�ria alocada para um processo.
 */
void liberarMemoria(int pid) {
    int encontrou = 0;
    for (int i = 0; i < num_blocos; i++) {
        if (blocos_memoria[i].pid == pid) {
            blocos_memoria[i].pid = 0;
            encontrou = 1;
            printf("Memoria do processo %d liberada.\n", pid);
        }
    }
    if (!encontrou) {
        printf("Processo %d nao possui memoria alocada.\n", pid);
    } else {
        mesclarBlocos();
    }
}

/**
 * Exibe o mapa de mem�ria mostrando blocos ocupados e livres.
 */
void exibirMapaMemoria() {
    printf("\n--- Mapa de Memoria (total: %d MB) ---\n", MEMORIA_TOTAL);
    if (num_blocos == 0) {
        printf("Nenhum bloco.\n");
        return;
    }
    for (int i = 0; i < num_blocos; i++) {
        BlocoMemoria *b = &blocos_memoria[i];
        printf("Bloco %d: base=%d, tamanho=%d MB, ", i, b->base, b->tamanho);
        if (b->pid == 0) {
            printf("LIVRE\n");
        } else {
            // Buscar nome do processo (opcional)
            Processo *p;
            if (obterProcessoPorPID(b->pid, &p)) {
                printf("OCUPADO por %s (PID %d)\n", p->nome, b->pid);
            } else {
                printf("OCUPADO por PID %d\n", b->pid);
            }
        }
    }
    printf("\n");
}
