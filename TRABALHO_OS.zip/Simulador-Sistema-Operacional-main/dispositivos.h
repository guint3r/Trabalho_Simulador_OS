#ifndef DISPOSITIVOS_H
#define DISPOSITIVOS_H

#define NUM_DISPOSITIVOS 3
#define MAX_FILA_ESPERA 20

typedef struct {
    char nome[20];
    int ocupado;       // 0 = livre, 1 = ocupado
    int pid_utilizador;
    int fila_espera[MAX_FILA_ESPERA];
    int num_espera;
} Dispositivo;

extern Dispositivo dispositivos[NUM_DISPOSITIVOS];

void inicializarDispositivos();
void solicitarDispositivo(int pid, int id_dispositivo);
void liberarDispositivo(int id_dispositivo);
void exibirDispositivos();

#endif
