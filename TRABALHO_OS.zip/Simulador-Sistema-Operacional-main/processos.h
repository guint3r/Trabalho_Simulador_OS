#ifndef PROCESSOS_H
#define PROCESSOS_H

#define MAX_PROCESSOS 50

typedef enum {
    NEW,
    READY,
    RUNNING,
    WAITING,
    TERMINATED
} EstadoProcesso;

typedef struct {
    int pid;
    char nome[30];
    int prioridade;         // 0 a 10 (maior valor = maior prioridade, apenas para exibi��o)
    int tempo_execucao;     // em unidades de tempo
    EstadoProcesso estado;
    int tempo_chegada;      // instante em que ficou pronto (para estat�sticas)
    int tempo_inicio;       // instante em que come�ou a executar
    int tempo_fim;          // instante em que terminou
} Processo;

extern Processo processos[MAX_PROCESSOS];
extern int num_processos;
extern int proximo_pid;

void inicializarProcessos();
int criarProcesso(char *nome, int prioridade, int tempo_exec);
int encerrarProcesso(int pid);
int alterarEstadoProcesso(int pid, EstadoProcesso novo_estado);
void exibirProcessos();
int obterProcessoPorPID(int pid, Processo **p);

#endif
