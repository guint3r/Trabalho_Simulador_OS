#ifndef ESCALONADOR_H
#define ESCALONADOR_H

void escalonarFCFS();
void escalonarRoundRobin(int quantum);

#endif
