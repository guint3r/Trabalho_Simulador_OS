#include <stdio.h>
#include "utils.h"

/**
 * Limpa o buffer do teclado (descarta caracteres pendentes).
 */
void limparBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

/**
 * Pausa a execu��o at� que o usu�rio pressione Enter.
 */
void pausar() {
    printf("\nPressione Enter para continuar...");
    limparBuffer();
    getchar();
}
