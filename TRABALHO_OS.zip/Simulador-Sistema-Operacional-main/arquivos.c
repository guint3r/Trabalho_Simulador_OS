#include <stdio.h>
#include <string.h>
#include "arquivos.h"
#include "utils.h"

Arquivo arquivos[MAX_ARQUIVOS];
int num_arquivos = 0;

/**
 * Inicializa a lista de arquivos.
 */
void inicializarArquivos() {
    num_arquivos = 0;
}

/**
 * Cria um novo arquivo (simples, sem verifica��o de duplicidade).
 */
void criarArquivo(char *nome, int tamanho) {
    if (num_arquivos >= MAX_ARQUIVOS) {
        printf("Erro: numero maximo de arquivos atingido.\n");
        return;
    }
    // Verifica se nome j� existe
    for (int i = 0; i < num_arquivos; i++) {
        if (strcmp(arquivos[i].nome, nome) == 0) {
            printf("Arquivo %s ja existe.\n", nome);
            return;
        }
    }
    strcpy(arquivos[num_arquivos].nome, nome);
    arquivos[num_arquivos].tamanho = tamanho;
    num_arquivos++;
    printf("Arquivo %s criado com tamanho %d KB.\n", nome, tamanho);
}

/**
 * Remove um arquivo pelo nome.
 */
void removerArquivo(char *nome) {
    int pos = -1;
    for (int i = 0; i < num_arquivos; i++) {
        if (strcmp(arquivos[i].nome, nome) == 0) {
            pos = i;
            break;
        }
    }
    if (pos == -1) {
        printf("Arquivo %s nao encontrado.\n", nome);
        return;
    }
    // Desloca os elementos seguintes
    for (int i = pos; i < num_arquivos - 1; i++) {
        arquivos[i] = arquivos[i + 1];
    }
    num_arquivos--;
    printf("Arquivo %s removido.\n", nome);
}

/**
 * Lista todos os arquivos.
 */
void listarArquivos() {
    if (num_arquivos == 0) {
        printf("Nenhum arquivo.\n");
        return;
    }
    printf("\n--- Lista de Arquivos ---\n");
    printf("Nome                Tamanho (KB)\n");
    printf("------------------- ------------\n");
    for (int i = 0; i < num_arquivos; i++) {
        printf("%-19s %d\n", arquivos[i].nome, arquivos[i].tamanho);
    }
    printf("\n");
}

/**
 * Busca um arquivo pelo nome e exibe seu tamanho.
 */
void buscarArquivo(char *nome) {
    for (int i = 0; i < num_arquivos; i++) {
        if (strcmp(arquivos[i].nome, nome) == 0) {
            printf("Arquivo encontrado: %s, tamanho %d KB.\n", nome, arquivos[i].tamanho);
            return;
        }
    }
    printf("Arquivo %s nao encontrado.\n", nome);
}
