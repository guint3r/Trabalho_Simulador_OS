#include <stdio.h>
#include <string.h>
#include "dispositivos.h"
#include "processos.h"
#include "utils.h"

Dispositivo dispositivos[NUM_DISPOSITIVOS];

/**
 * Inicializa os dispositivos com nomes e estado livre.
 */
void inicializarDispositivos() {
    const char *nomes[NUM_DISPOSITIVOS] = {"Impressora", "Scanner", "Disco"};
    for (int i = 0; i < NUM_DISPOSITIVOS; i++) {
        strcpy(dispositivos[i].nome, nomes[i]);
        dispositivos[i].ocupado = 0;
        dispositivos[i].pid_utilizador = 0;
        dispositivos[i].num_espera = 0;
    }
}

/**
 * Solicita um dispositivo para um processo.
 * Se livre, ocupa; se ocupado, adiciona � fila de espera.
 */
void solicitarDispositivo(int pid, int id_dispositivo) {
    if (id_dispositivo < 0 || id_dispositivo >= NUM_DISPOSITIVOS) {
        printf("Dispositivo invalido.\n");
        return;
    }
    Dispositivo *d = &dispositivos[id_dispositivo];
    if (d->ocupado == 0) {
        d->ocupado = 1;
        d->pid_utilizador = pid;
        printf("Processo %d obteve o dispositivo %s.\n", pid, d->nome);
    } else {
        // Adicionar � fila se houver espa�o
        if (d->num_espera < MAX_FILA_ESPERA) {
            d->fila_espera[d->num_espera++] = pid;
            printf("Processo %d adicionado a fila de espera do %s.\n", pid, d->nome);
        } else {
            printf("Fila de espera do %s est� cheia.\n", d->nome);
        }
    }
}

/**
 * Libera um dispositivo.
 * Se houver fila, atribui ao primeiro da fila.
 */
void liberarDispositivo(int id_dispositivo) {
    if (id_dispositivo < 0 || id_dispositivo >= NUM_DISPOSITIVOS) {
        printf("Dispositivo invalido.\n");
        return;
    }
    Dispositivo *d = &dispositivos[id_dispositivo];
    if (d->ocupado == 0) {
        printf("Dispositivo %s ja esta livre.\n", d->nome);
        return;
    }
    printf("Liberando %s do processo %d.\n", d->nome, d->pid_utilizador);
    if (d->num_espera > 0) {
        // Atribui ao primeiro da fila
        int novo_pid = d->fila_espera[0];
        // Remove da fila
        for (int i = 0; i < d->num_espera - 1; i++) {
            d->fila_espera[i] = d->fila_espera[i + 1];
        }
        d->num_espera--;
        d->pid_utilizador = novo_pid;
        // Permanece ocupado
        printf("Dispositivo %s agora a utilizado pelo processo %d (fila).\n", d->nome, novo_pid);
    } else {
        d->ocupado = 0;
        d->pid_utilizador = 0;
        printf("Dispositivo %s esta livre.\n", d->nome);
    }
}

/**
 * Exibe a situa��o de todos os dispositivos.
 */
void exibirDispositivos() {
    printf("\n--- Dispositivos ---\n");
    for (int i = 0; i < NUM_DISPOSITIVOS; i++) {
        Dispositivo *d = &dispositivos[i];
        printf("%s: ", d->nome);
        if (d->ocupado) {
            printf("OCUPADO pelo PID %d", d->pid_utilizador);
            if (d->num_espera > 0) {
                printf(", fila de espera: ");
                for (int j = 0; j < d->num_espera; j++) {
                    printf("%d ", d->fila_espera[j]);
                }
            }
            printf("\n");
        } else {
            printf("LIVRE\n");
        }
    }
    printf("\n");
}
