#ifndef MEMORIA_H
#define MEMORIA_H

#define MEMORIA_TOTAL 1024

typedef struct {
    int base;        // endere�o inicial do bloco
    int tamanho;     // em MB
    int pid;         // 0 = livre, >0 = ocupado pelo processo
} BlocoMemoria;

extern BlocoMemoria blocos_memoria[100];
extern int num_blocos;

void inicializarMemoria();
void alocarMemoria(int pid, int tamanho);
void liberarMemoria(int pid);
void exibirMapaMemoria();

#endif
