#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "processos.h"
#include "escalonador.h"
#include "memoria.h"
#include "dispositivos.h"
#include "arquivos.h"
#include "utils.h"

// Vari�veis globais para estat�sticas (declaradas em escalonador.c)
extern double tempo_medio_espera;
extern double tempo_medio_retorno;
extern double throughput;
extern int total_processos_escalonados;
extern int tempo_total_simulacao;

/**
 * Exibe o menu principal e retorna a op��o escolhida.
 */
int menu() {
    int opcao;
    printf("\n====================================\n");
    printf("--SIMULADOR DE SISTEMA OPERACIONAL--\n");
    printf("====================================\n");
    printf("1 - Gerenciamento de Processos\n");
    printf("2 - Executar Escalonador\n");
    printf("3 - Exibir Processos\n");
    printf("4 - Gerenciar Memoria\n");
    printf("5 - Gerenciar Dispositivos\n");
    printf("6 - Sistema de Arquivos\n");
    printf("7 - Estatisticas\n");
    printf("0 - Sair\n");
    printf("Escolha: ");
    scanf("%d", &opcao);
    limparBuffer();
    return opcao;
}

/**
 * Submenu para gerenciar processos (criar, encerrar, alterar estado).
 */
void submenuProcessos() {
    int opcao;
    do {
        printf("\n--- Gerenciamento de Processos ---\n");
        printf("1 - Criar Processo\n");
        printf("2 - Encerrar Processo\n");
        printf("3 - Alterar Estado\n");
        printf("4 - Exibir Tabela\n");
        printf("0 - Voltar\n");
        printf("Escolha: ");
        scanf("%d", &opcao);
        limparBuffer();

        switch (opcao) {
            case 1: {
                char nome[30];
                int prioridade, tempo;
                printf("Nome do processo: ");
                fgets(nome, sizeof(nome), stdin);
                nome[strcspn(nome, "\n")] = '\0'; // remove newline
                printf("Prioridade (0-10): ");
                scanf("%d", &prioridade);
                limparBuffer();
                printf("Tempo de execucao: ");
                scanf("%d", &tempo);
                limparBuffer();
                criarProcesso(nome, prioridade, tempo);
                break;
            }
            case 2: {
                int pid;
                printf("PID do processo a encerrar: ");
                scanf("%d", &pid);
                limparBuffer();
                encerrarProcesso(pid);
                break;
            }
            case 3: {
                int pid, estado_int;
                printf("PID do processo: ");
                scanf("%d", &pid);
                limparBuffer();
                printf("Novo estado (0=NEW, 1=READY, 2=RUNNING, 3=WAITING, 4=TERMINATED): ");
                scanf("%d", &estado_int);
                limparBuffer();
                if (estado_int < 0 || estado_int > 4) {
                    printf("Estado invalido.\n");
                } else {
                    alterarEstadoProcesso(pid, (EstadoProcesso)estado_int);
                }
                break;
            }
            case 4:
                exibirProcessos();
                break;
            case 0:
                break;
            default:
                printf("Op��o invalida.\n");
        }
        if (opcao != 0) pausar();
    } while (opcao != 0);
}

/**
 * Submenu para executar escalonador.
 */
void submenuEscalonador() {
    int opcao;
    printf("\n--- Escalonador ---\n");
    printf("1 - FCFS\n");
    printf("2 - Round Robin\n");
    printf("0 - Voltar\n");
    printf("Escolha: ");
    scanf("%d", &opcao);
    limparBuffer();

    switch (opcao) {
        case 1:
            escalonarFCFS();
            break;
        case 2: {
            int quantum;
            printf("Informe o quantum: ");
            scanf("%d", &quantum);
            limparBuffer();
            escalonarRoundRobin(quantum);
            break;
        }
        case 0:
            break;
        default:
            printf("Opcao invalida.\n");
    }
}

/**
 * Submenu para gerenciamento de mem�ria.
 */
void submenuMemoria() {
    int opcao;
    do {
        printf("\n--- Gerenciamento de Memoria ---\n");
        printf("1 - Alocar memoria para processo\n");
        printf("2 - Liberar memoria de processo\n");
        printf("3 - Exibir mapa de memoria\n");
        printf("0 - Voltar\n");
        printf("Escolha: ");
        scanf("%d", &opcao);
        limparBuffer();

        switch (opcao) {
            case 1: {
                int pid, tamanho;
                printf("PID do processo: ");
                scanf("%d", &pid);
                limparBuffer();
                // Verifica se o processo existe
                Processo *p;
                if (!obterProcessoPorPID(pid, &p)) {
                    printf("Processo nao encontrado.\n");
                    break;
                }
                printf("Tamanho a alocar (MB): ");
                scanf("%d", &tamanho);
                limparBuffer();
                alocarMemoria(pid, tamanho);
                break;
            }
            case 2: {
                int pid;
                printf("PID do processo: ");
                scanf("%d", &pid);
                limparBuffer();
                liberarMemoria(pid);
                break;
            }
            case 3:
                exibirMapaMemoria();
                break;
            case 0:
                break;
            default:
                printf("Opcao invalida.\n");
        }
        if (opcao != 0) pausar();
    } while (opcao != 0);
}

/**
 * Submenu para gerenciamento de dispositivos.
 */
void submenuDispositivos() {
    int opcao;
    do {
        printf("\n--- Gerenciamento de Dispositivos ---\n");
        printf("1 - Solicitar dispositivo\n");
        printf("2 - Liberar dispositivo\n");
        printf("3 - Exibir situacao\n");
        printf("0 - Voltar\n");
        printf("Escolha: ");
        scanf("%d", &opcao);
        limparBuffer();

        switch (opcao) {
            case 1: {
                int pid, id;
                printf("PID do processo: ");
                scanf("%d", &pid);
                limparBuffer();
                printf("ID do dispositivo (0=Impressora, 1=Scanner, 2=Disco): ");
                scanf("%d", &id);
                limparBuffer();
                Processo *p;
                if (!obterProcessoPorPID(pid, &p)) {
                    printf("Processo nao encontrado.\n");
                    break;
                }
                solicitarDispositivo(pid, id);
                break;
            }
            case 2: {
                int id;
                printf("ID do dispositivo a liberar (0=Impressora, 1=Scanner, 2=Disco): ");
                scanf("%d", &id);
                limparBuffer();
                liberarDispositivo(id);
                break;
            }
            case 3:
                exibirDispositivos();
                break;
            case 0:
                break;
            default:
                printf("Opcao invalida.\n");
        }
        if (opcao != 0) pausar();
    } while (opcao != 0);
}

/**
 * Submenu para sistema de arquivos.
 */
void submenuArquivos() {
    int opcao;
    do {
        printf("\n--- Sistema de Arquivos ---\n");
        printf("1 - Criar arquivo\n");
        printf("2 - Remover arquivo\n");
        printf("3 - Listar arquivos\n");
        printf("4 - Buscar arquivo\n");
        printf("0 - Voltar\n");
        printf("Escolha: ");
        scanf("%d", &opcao);
        limparBuffer();

        switch (opcao) {
            case 1: {
                char nome[30];
                int tamanho;
                printf("Nome do arquivo: ");
                fgets(nome, sizeof(nome), stdin);
                nome[strcspn(nome, "\n")] = '\0';
                printf("Tamanho (KB): ");
                scanf("%d", &tamanho);
                limparBuffer();
                criarArquivo(nome, tamanho);
                break;
            }
            case 2: {
                char nome[30];
                printf("Nome do arquivo a remover: ");
                fgets(nome, sizeof(nome), stdin);
                nome[strcspn(nome, "\n")] = '\0';
                removerArquivo(nome);
                break;
            }
            case 3:
                listarArquivos();
                break;
            case 4: {
                char nome[30];
                printf("Nome do arquivo a buscar: ");
                fgets(nome, sizeof(nome), stdin);
                nome[strcspn(nome, "\n")] = '\0';
                buscarArquivo(nome);
                break;
            }
            case 0:
                break;
            default:
                printf("Opcao invalida.\n");
        }
        if (opcao != 0) pausar();
    } while (opcao != 0);
}

/**
 * Exibe estat�sticas gerais do sistema.
 */
void exibirEstatisticas() {
    printf("\n--- Estatisticas do Sistema ---\n");

    // Processos
    int ativos = 0, finalizados = 0;
    for (int i = 0; i < num_processos; i++) {
        if (processos[i].estado == TERMINATED)
            finalizados++;
        else
            ativos++;
    }
    printf("Total de processos criados: %d\n", num_processos);
    printf("Processos ativos: %d\n", ativos);
    printf("Processos finalizados: %d\n", finalizados);

    // Mem�ria
    int memoria_utilizada = 0;
    for (int i = 0; i < num_blocos; i++) {
        if (blocos_memoria[i].pid != 0)
            memoria_utilizada += blocos_memoria[i].tamanho;
    }
    printf("Memoria utilizada: %d MB\n", memoria_utilizada);
    printf("Memoria livre: %d MB\n", MEMORIA_TOTAL - memoria_utilizada);

    // Arquivos
    printf("Quantidade de arquivos: %d\n", num_arquivos);

    // Dispositivos
    printf("Estado dos dispositivos:\n");
    for (int i = 0; i < NUM_DISPOSITIVOS; i++) {
        printf("  %s: %s\n", dispositivos[i].nome,
               dispositivos[i].ocupado ? "Ocupado" : "Livre");
    }

    // Escalonamento
    printf("Resultados do escalonamento (ultima execucao):\n");
    printf("  Tempo medio de espera: %.2f\n", tempo_medio_espera);
    printf("  Tempo medio de retorno: %.2f\n", tempo_medio_retorno);
    printf("  Throughput: %.4f processos/unidade\n", throughput);
    printf("  Total de processos escalonados: %d\n", total_processos_escalonados);
    printf("  Tempo total de simulacao: %d\n", tempo_total_simulacao);

    pausar();
}

/**
 * Fun��o principal.
 */
int main() {
    // Inicializa todos os m�dulos
    inicializarProcessos();
    inicializarMemoria();
    inicializarDispositivos();
    inicializarArquivos();

    int opcao;
    do {
        opcao = menu();
        switch (opcao) {
            case 1:
                submenuProcessos();
                break;
            case 2:
                submenuEscalonador();
                break;
            case 3:
                exibirProcessos();
                pausar();
                break;
            case 4:
                submenuMemoria();
                break;
            case 5:
                submenuDispositivos();
                break;
            case 6:
                submenuArquivos();
                break;
            case 7:
                exibirEstatisticas();
                break;
            case 0:
                printf("Encerrando simulador...\n");
                break;
            default:
                printf("Opcao invalida.\n");
                pausar();
        }
    } while (opcao != 0);

    return 0;
}
