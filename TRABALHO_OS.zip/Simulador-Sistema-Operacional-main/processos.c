#include <stdio.h>
#include <string.h>
#include "processos.h"
#include "utils.h"

// Defini��o das vari�veis globais
Processo processos[MAX_PROCESSOS];
int num_processos = 0;
int proximo_pid = 1;

/**
 * Inicializa a lista de processos (zera contadores).
 */
void inicializarProcessos() {
    num_processos = 0;
    proximo_pid = 1;
}

/**
 * Cria um novo processo com estado NEW.
 * Retorna o PID se bem-sucedido, ou -1 em caso de erro.
 */
int criarProcesso(char *nome, int prioridade, int tempo_exec) {
    if (num_processos >= MAX_PROCESSOS) {
        printf("Erro: limite maximo de processos atingido.\n");
        return -1;
    }
    if (prioridade < 0 || prioridade > 10) {
        printf("Erro: prioridade deve estar entre 0 e 10.\n");
        return -1;
    }
    if (tempo_exec <= 0) {
        printf("Erro: tempo de execucao deve ser positivo.\n");
        return -1;
    }

    Processo *p = &processos[num_processos];
    p->pid = proximo_pid++;
    strcpy(p->nome, nome);
    p->prioridade = prioridade;
    p->tempo_execucao = tempo_exec;
    p->estado = NEW;
    p->tempo_chegada = 0;
    p->tempo_inicio = 0;
    p->tempo_fim = 0;
    num_processos++;

    printf("Processo criado com PID %d\n", p->pid);
    return p->pid;
}

/**
 * Encerra um processo (muda estado para TERMINATED).
 * Retorna 1 se bem-sucedido, 0 se n�o encontrado.
 */
int encerrarProcesso(int pid) {
    for (int i = 0; i < num_processos; i++) {
        if (processos[i].pid == pid) {
            if (processos[i].estado == TERMINATED) {
                printf("Processo ja esta terminado.\n");
                return 0;
            }
            processos[i].estado = TERMINATED;
            printf("Processo %d encerrado.\n", pid);
            return 1;
        }
    }
    printf("Processo com PID %d nao encontrado.\n", pid);
    return 0;
}

/**
 * Altera o estado de um processo.
 * Retorna 1 se bem-sucedido, 0 se n�o encontrado.
 */
int alterarEstadoProcesso(int pid, EstadoProcesso novo_estado) {
    for (int i = 0; i < num_processos; i++) {
        if (processos[i].pid == pid) {
            processos[i].estado = novo_estado;
            printf("Estado do processo %d alterado para %d.\n", pid, novo_estado);
            return 1;
        }
    }
    printf("Processo com PID %d nao encontrado.\n", pid);
    return 0;
}

/**
 * Exibe a tabela de processos com todos os campos.
 */
void exibirProcessos() {
    if (num_processos == 0) {
        printf("Nenhum processo cadastrado.\n");
        return;
    }
    printf("\n--- Tabela de Processos ---\n");
    printf("PID  Nome            Prioridade  Tempo  Estado\n");
    printf("---- --------------- ----------- ------ ----------\n");
    for (int i = 0; i < num_processos; i++) {
        Processo *p = &processos[i];
        char estado_str[12];
        switch (p->estado) {
            case NEW:        strcpy(estado_str, "NEW"); break;
            case READY:      strcpy(estado_str, "READY"); break;
            case RUNNING:    strcpy(estado_str, "RUNNING"); break;
            case WAITING:    strcpy(estado_str, "WAITING"); break;
            case TERMINATED: strcpy(estado_str, "TERMINATED"); break;
            default:         strcpy(estado_str, "UNKNOWN"); break;
        }
        printf("%-4d %-15s %-11d %-6d %s\n",
               p->pid, p->nome, p->prioridade, p->tempo_execucao, estado_str);
    }
    printf("\n");
}

/**
 * Retorna o ponteiro para o processo com o PID informado.
 * Retorna 1 se encontrado, 0 caso contr�rio.
 */
int obterProcessoPorPID(int pid, Processo **p) {
    for (int i = 0; i < num_processos; i++) {
        if (processos[i].pid == pid) {
            *p = &processos[i];
            return 1;
        }
    }
    return 0;
}
