#ifndef ARQUIVOS_H
#define ARQUIVOS_H

#define MAX_ARQUIVOS 50
#define MAX_NOME_ARQ 30

typedef struct {
    char nome[MAX_NOME_ARQ];
    int tamanho;   // em KB (apenas para exibi��o)
} Arquivo;

extern Arquivo arquivos[MAX_ARQUIVOS];
extern int num_arquivos;

void inicializarArquivos();
void criarArquivo(char *nome, int tamanho);
void removerArquivo(char *nome);
void listarArquivos();
void buscarArquivo(char *nome);

#endif
