#include <stdio.h>
#include <string.h>
#include "escalonador.h"
#include "processos.h"
#include "utils.h"

// Vari�veis globais para estat�sticas (acess�veis pelo m�dulo de estat�sticas)
double tempo_medio_espera = 0.0;
double tempo_medio_retorno = 0.0;
double throughput = 0.0;
int total_processos_escalonados = 0;
int tempo_total_simulacao = 0;

/**
 * Fun��o auxiliar que calcula estat�sticas ap�s a simula��o.
 * Recebe um vetor de processos (ponteiros) que foram executados e o n�mero.
 */
static void calcularEstatisticas(Processo *executados[], int count, int tempo_total) {
    if (count == 0) {
        tempo_medio_espera = 0.0;
        tempo_medio_retorno = 0.0;
        throughput = 0.0;
        return;
    }
    double soma_espera = 0.0;
    double soma_retorno = 0.0;
    int terminados = 0;
    for (int i = 0; i < count; i++) {
        Processo *p = executados[i];
        if (p->estado == TERMINATED) {
            soma_espera += (p->tempo_inicio - p->tempo_chegada);
            soma_retorno += (p->tempo_fim - p->tempo_chegada);
            terminados++;
        }
    }
    if (terminados > 0) {
        tempo_medio_espera = soma_espera / terminados;
        tempo_medio_retorno = soma_retorno / terminados;
    } else {
        tempo_medio_espera = 0.0;
        tempo_medio_retorno = 0.0;
    }
    // Throughput: processos terminados por unidade de tempo
    if (tempo_total > 0) {
        throughput = (double)terminados / tempo_total;
    } else {
        throughput = 0.0;
    }
    total_processos_escalonados = count;
    tempo_total_simulacao = tempo_total;
}

/**
 * Escalonamento FCFS (First-Come, First-Served).
 * Executa os processos em ordem de cria��o (PID crescente) que estiverem READY.
 */
void escalonarFCFS() {
    // Coletar processos prontos (READY) ordenados por PID (cria��o)
    Processo *prontos[MAX_PROCESSOS];
    int qtd = 0;
    for (int i = 0; i < num_processos; i++) {
        if (processos[i].estado == READY) {
            prontos[qtd++] = &processos[i];
        }
    }

    if (qtd == 0) {
        printf("Nenhum processo no estado READY para escalonar.\n");
        pausar();
        return;
    }

    // Ordenar por PID (ordem de cria��o) - simples bolha
    for (int i = 0; i < qtd - 1; i++) {
        for (int j = i + 1; j < qtd; j++) {
            if (prontos[i]->pid > prontos[j]->pid) {
                Processo *aux = prontos[i];
                prontos[i] = prontos[j];
                prontos[j] = aux;
            }
        }
    }

    printf("\n--- Escalonamento FCFS ---\n");
    int tempo_atual = 0;
    // Definir tempos de chegada (todos chegam no instante 0, pois est�o READY)
    for (int i = 0; i < qtd; i++) {
        prontos[i]->tempo_chegada = 0;
    }

    // Executar cada processo
    for (int i = 0; i < qtd; i++) {
        Processo *p = prontos[i];
        p->estado = RUNNING;
        p->tempo_inicio = tempo_atual;
        printf("Executando Processo %d (%s) por %d unidades de tempo\n",
               p->pid, p->nome, p->tempo_execucao);
        tempo_atual += p->tempo_execucao;
        p->tempo_fim = tempo_atual;
        p->estado = TERMINATED;
        printf("Processo %d finalizado no instante %d\n", p->pid, tempo_atual);
    }

    // Calcular estat�sticas
    calcularEstatisticas(prontos, qtd, tempo_atual);
    printf("\nTempo total de simulacao: %d\n", tempo_atual);
    printf("Tempo medio de espera: %.2f\n", tempo_medio_espera);
    printf("Tempo medio de retorno: %.2f\n", tempo_medio_retorno);
    printf("Throughput: %.4f processos/unidade\n", throughput);
    pausar();
}

/**
 * Escalonamento Round Robin.
 * O usu�rio fornece o quantum. Os processos READY s�o executados em fila circular.
 */
void escalonarRoundRobin(int quantum) {
    if (quantum <= 0) {
        printf("Quantum deve ser positivo.\n");
        pausar();
        return;
    }

    // Coletar processos prontos
    Processo *prontos[MAX_PROCESSOS];
    int qtd = 0;
    for (int i = 0; i < num_processos; i++) {
        if (processos[i].estado == READY) {
            prontos[qtd++] = &processos[i];
        }
    }

    if (qtd == 0) {
        printf("Nenhum processo no estado READY para escalonar.\n");
        pausar();
        return;
    }

    // Ordenar por PID para definir ordem inicial
    for (int i = 0; i < qtd - 1; i++) {
        for (int j = i + 1; j < qtd; j++) {
            if (prontos[i]->pid > prontos[j]->pid) {
                Processo *aux = prontos[i];
                prontos[i] = prontos[j];
                prontos[j] = aux;
            }
        }
    }

    printf("\n--- Escalonamento Round Robin (quantum = %d) ---\n", quantum);
    int tempo_atual = 0;
    // Todos chegam no instante 0
    for (int i = 0; i < qtd; i++) {
        prontos[i]->tempo_chegada = 0;
    }

    // Guardar o tempo restante de cada processo (c�pia do tempo_execucao)
    int restante[MAX_PROCESSOS];
    for (int i = 0; i < qtd; i++) {
        restante[i] = prontos[i]->tempo_execucao;
    }

    int terminados = 0;
    int primeiro = 1; // indica se � a primeira execu��o de cada processo

    // Fila circular: usamos �ndice (fila[0..qtd-1])
    int fila[MAX_PROCESSOS];
    for (int i = 0; i < qtd; i++) fila[i] = i;
    int head = 0;
    int count = qtd; // n�mero de processos na fila (ainda n�o terminados)

    while (count > 0) {
        int idx = fila[head];
        Processo *p = prontos[idx];

        // Se � a primeira vez que executa, marca in�cio
        if (primeiro) {
            p->tempo_inicio = tempo_atual;
            primeiro = 0;
        }

        // Determinar quanto executar
        int exec = (restante[idx] < quantum) ? restante[idx] : quantum;
        p->estado = RUNNING;
        printf("Executando Processo %d (%s) por %d unidades de tempo\n",
               p->pid, p->nome, exec);
        tempo_atual += exec;
        restante[idx] -= exec;

        if (restante[idx] == 0) {
            // Processo terminou
            p->estado = TERMINATED;
            p->tempo_fim = tempo_atual;
            printf("Processo %d finalizado no instante %d\n", p->pid, tempo_atual);
            terminados++;
            // Remover da fila: deslocar os elementos seguintes
            for (int i = head; i < count - 1; i++) {
                fila[i] = fila[i + 1];
            }
            count--;
            // head permanece no mesmo �ndice, a menos que tenha sido o �ltimo
            if (head >= count) head = 0;
        } else {
            // Vai para o final da fila
            // Se head n�o for o �ltimo, rotacionamos
            // Avan�ar head
            head = (head + 1) % count;
        }
        // Pequena pausa para visualiza��o (opcional)
        // Podemos n�o pausar para n�o tornar a execu��o muito lenta
    }

    // Calcular estat�sticas
    // Precisamos dos processos que foram executados (todos em prontos)
    calcularEstatisticas(prontos, qtd, tempo_atual);
    printf("\nTempo total de simulacao: %d\n", tempo_atual);
    printf("Tempo medio de espera: %.2f\n", tempo_medio_espera);
    printf("Tempo medio de retorno: %.2f\n", tempo_medio_retorno);
    printf("Throughput: %.4f processos/unidade\n", throughput);
    pausar();
}
